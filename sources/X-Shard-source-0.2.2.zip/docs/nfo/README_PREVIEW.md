# README preview assets

- `preview/preview.jpg` — production screenshot of the main window, referenced by README.md (since 0.1.9).
- `preview/favicon.png` — color logo.
- `src/XShard/Assets/app-logo-light.png` — all-green logo used by the Light theme (header and About) and for the small installer image.
- `installer/wizard/*.png` — Inno Setup wizard images (since 0.2.0): large = logo on the green gradient, small = logo with transparent background; regenerate with `installer/wizard/make-wizard-images.py`.
