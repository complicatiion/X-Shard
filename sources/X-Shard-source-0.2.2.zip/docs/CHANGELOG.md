# Changelog

## 0.2.2

### New

- **Update check** (Settings › Updates): asks GitHub (`complicatiion/X-Shard`, release tags like `0.2.2`, `v0.2.2` also accepted) for the latest release – only after a one-time Yes. Automatic check at start (max. once a day) is **off by default**; notification as message in the card, Windows notification and a badge on the settings button. "Open release page"; X-Shard never downloads or installs updates itself.
- **Emulator downloads (optional):** Xenia Canary (BSD-3-Clause) and xemu (GPL-2.0) can be downloaded or updated from their official GitHub releases after an explicit Yes that names project, license and source. Nothing is bundled.
  - HTTPS only, redirects only to GitHub hosts, SHA-256 checked against the digest GitHub publishes, size limits, protection against archive entries outside the target folder, installation into a working folder and swap; the previous version is kept as `<name>.previous`; nothing is started automatically.
  - The emulator path is set automatically; buttons open the emulator folders.
  - **xemu system files:** button opens `emulators\xemu\system` for your own MCPX boot ROM, flash BIOS and HDD image (qcow2). These files are not provided; they are carried over on updates.
- **Skip existing games** can be switched off (Settings › options). Probably scrubbed GoD packages are not counted as existing, so the ISO can be added to rebuild them with Scrub None.
- Job details: "Send result to console" for finished GoD/extract jobs; the console path is shown after a transfer.

### Changed

- Settings layout: *Settings and queue location* and the new *Updates* card moved to the right column; columns are balanced; section headers with icons.
- Main window: *Skip $SystemUpdate*, *Disable XBE media patching* and *Advanced XGD options* are switches (label on the right, accent color).
- Console target: the output field shows "Console <IP> · /Hdd1" (transfer folder as tooltip).
- Rewrite with XGDTool follows the Scrub selection (None keeps the padding); formerly always Full. The scrub label no longer says "Rewrite always Full".
- Adding sources shows progress (folders, games) and can be cancelled.
- Legal documents: EULA 5.3/5a (update check only informs; third-party emulators are subject to their own licenses, no system files are provided) and Privacy Policy section 3 (GitHub update check and emulator downloads). The documents must be accepted again once.

### Fixed

- Console jobs no longer start without FTP enabled, a console address or a valid port (checked before the run, not after converting).
- FTP port: invalid input shows an error instead of silently using 21.
- Transfer folder: size shown in the FTP card, "Clean up" removes leftovers (results of jobs still in the queue and live working folders are kept; not available while the queue runs).
- Emulator updates move the user's files (system dumps, configuration, anything not shipped in the previous archive) only after the old version was renamed; any failure rolls back, user files are never deleted.
- Emulator downloads: only assets from the releases of the emulator's own repository; without a published checksum X-Shard asks again; stalled downloads stop after 60 s without data; downloads can be cancelled.
- **Build:** new release script `build/publish.ps1` (replaces `installer/publish-portable.ps1`): self-contained portable ZIP and Inno Setup installer in one run, `-PortableOnly`, `-InstallerOnly`, `-Clean`, `-OutputDir`, `-Open`, .NET SDK check, combined `SHA256SUMS.txt`. Visual Studio Release builds call it automatically.

## 0.2.1

### Changed

- **Xbox 360 console GoD keeps its padding:** the profile *Xbox 360* (now *Xbox 360 · Console (RGH/JTAG)*) creates GoD with **Scrub None**. Partial/full-scrubbed (rebuilt) GoD does not start for some titles on the console, e.g. games with an install disc. The *Xbox 360 · Xenia* profile keeps full-scrub XISO.
- Existing settings that still used the former profile default (Xbox 360 + Full) are switched to None once; values you changed yourself stay.
- Output target *Xbox 360 console (FTP)* sets Scrub to None automatically.
- **Privacy Policy** section 3 "Optional Network Features" (network shares, console transfer via FTP, online lookups) added; the legal documents must be accepted again once.

### New

- Warning in the target preview and the job log when Xbox 360 GoD is created with scrub; tooltip on the Scrub selection explains None / Partial / Full.
- Job details and run report show format and scrub per job (e.g. "Convert · GoD · Scrub None"); Rewrite of Xbox 360 images is labeled "rebuilt (full scrub)".
- `xshard-cli scan` marks GoD packages that were probably scrubbed (data clearly smaller than a full game partition) – candidates to rebuild from the ISO with Scrub None.
- *Send to console* with extracted folders shows a hint that install-disc games do not run extracted.

### Fixed

- Console FTP servers without resume support (APPE/REST): interrupted files are sent again from the start instead of retrying endlessly.
- Reachability checks of a dead share no longer block additional worker threads (one probe per share at a time).

## 0.2.0

### New

- **Network shares as sources and targets** (SMB/NAS, `\\server\share` or mapped drives) without a separate mode:
  - Mapped drive letters are stored as UNC paths (also valid elevated, in `xshard-cli` and in scheduled tasks).
  - New resilient I/O layer (`ResilientIO`): network errors are recognized (Win32/errno), the share is polled every 5 s for up to 10 min, copies resume at the last confirmed offset, renames are idempotent.
  - Jobs with network paths wait for unreachable shares and are restarted automatically (up to 3 times) when the connection drops while the backend runs; the queue continues with the next job afterwards.
  - Extract to a share: output is prepared on the local disk and copied to a private folder on the share with 8 files in parallel, then renamed into place. GoD/image output is written to the share directly.
  - Adding sources, folder scans, title reads and the target preview run in the background, so a slow or offline share never freezes the window; network sources show a small network icon in the queue.
- **Library check by Title ID:** when sources are added, games that already exist in the output folder as ISO, GoD or extracted folder (Title ID + Media ID + disc) are skipped and listed. `xshard-cli scan <folder>` lists a library; `--skip-existing` for batch runs.
- **Xbox 360 console transfer via FTP** (RGH/JTAG with Aurora, also FSD), **off by default**, switch in Settings › Xbox 360 console (FTP) with Aurora notes:
  - Console profile: IP, port, user, password (DPAPI-encrypted for the Windows account; Aurora default xboxftp/xboxftp), drive (default `Hdd1`), folder for extracted games, connection test.
  - New output target **Xbox 360 console (FTP)**: results are prepared in X-Shard's transfer folder, sent to the console and the local copy is deleted after a verified upload (option). Conversion of the next game runs while the previous one is sent.
  - **Send to console** for existing GoD or extracted game folders (also from the NAS); the source folder is never changed.
  - GoD → `/Hdd1/Content/0000000000000000/<TitleID>/00007000` (files via temporary name + rename, STFS headers last); extracted → `/Hdd1/Games/<name>` via a `.xsp` folder that is renamed when complete; FATX name rules (42 characters, ASCII) are checked before sending.
  - Interrupted transfers reconnect when the console is reachable again and resume at the transferred size; every file is size-checked; games already on the console are skipped.
  - `xshard-cli send <folder>` and `--to-console` (settings or `--host`, `--ftp-user`, `--ftp-password`, `--drive`).
- Installer: wizard images as PNG – large image = logo on the green gradient without text or version, small image = logo only with transparent background (5 DPI sizes each).

### Changed and fixed

- Inno Setup 6.5.2 or newer is required (PNG wizard images); the release script checks the version.
- New dependencies: FluentFTP 54.2.1 (MIT), System.Security.Cryptography.ProtectedData 10.0.0 (MIT); notices in `licenses`.
- Queue: jobs show "Sending" while they are transferred to the console; the run report lists the console path.
- Retry of a failed console transfer only resends the existing result (no new conversion).
- Jobs run on worker threads; status and progress return to the window, so slow shares never block the UI. Ctrl+C in `xshard-cli` also cancels a running console transfer.

## 0.1.9

### New

- Appearance: new default theme **Dark** — neutral dark gray with the Windows 11 Mica backdrop (solid #202020 on Windows 10 or when transparency is off).
- New **Xbox** theme: the previous dark green theme; it always uses the Xbox green accent (accent picker disabled while active).
- Default accent color is **Green**; new optional accent **Windows** follows the Windows accent color and updates live when it changes.
- Default UI language remains English (also after Reset).
- Light theme uses the all-green X-Shard logo in the header and About dialog (the white "X" was invisible on light backgrounds).

### Changed and fixed

- Defaults: Dark theme + Green accent + English. Existing 0.1.8 settings keep their theme and accent ("Dark" now shows the gray Mica look; choose "Xbox" for the former green look). Settings from 0.1.9 pre-release builds that were auto-switched to Xbox/Windows are reset once to Dark/Green.
- Job details arrow expands the details inline again (regression in 0.1.8: a height check almost always fell back to the details window). The drawer takes 220–420 px from the queue (queue keeps at least 120 px); on small displays the workspace scrolls instead of opening the window. The selected job and the drawer are scrolled into view.
- Output target dropdown (Custom folder, Xemu, Xenia, RetroBat, Batocera) and the sort dropdown no longer show leading icons.
- Queue header: search box, status filter and sort dropdown are exactly 42 px high, matching the icon buttons; the after-queue dropdown uses the same height and no longer shows the power icon.
- Settings › Settings and queue location: Open log folder and Open reports folder share the full card width in two equal columns.
- "Settings saved" notification removed.
- First-start "X-Shard information" dialog (legal reader) follows the active theme: background and headings no longer use the fixed Xbox green.
- Publisher shown in Windows "Programs and Features" / "Installed apps" is now **sksdesign** (installer `AppPublisher`, `VersionInfoCompany`; `Company` in the EXE file properties). Author/copyright remain Sven Klocke.
- Installer: own wizard artwork — large X-Shard image with logo and green gradient on the welcome/finish pages, small logo tile on the other pages, in five DPI sizes (`installer/wizard`, regenerated by `make-wizard-images.py`).
- README with new preview screenshot (`preview/preview.jpg`) and favicon (`preview/favicon.png`).

## 0.1.8

### New

- Title information read offline from images and folders: Title ID (with publisher code), name, region, version, disc and title icon for Xbox Classic (`default.xbe`, incl. the DXT/XPR title image); Title ID, Media ID, region, version and disc for Xbox 360 (`default.xex`), name and icon from GoD/STFS headers. Shown in the queue row and in a new Title tab.
- Target preview tab (destination, expected structure, estimated size, free space incl. network shares) and a free-space warning before the queue starts.
- Run reports as TXT or self-contained HTML (status, duration, sizes, space saved); export from the queue footer or save automatically to the reports folder.
- Taskbar progress, taskbar flash and a Windows toast notification when the queue finishes (Windows SDK projection, toggle in Settings).
- Optional hibernate or shutdown after the queue with a 60-second countdown, Cancel and Now; session-only.
- Explorer context menu: Extract/Convert with X-Shard for .iso/.xiso, Create XISO with X-Shard for folders (installer task for all users, Settings toggle for the current user); single instance with a local named pipe forwards new files to the running window.
- `xshard-cli.exe`: extract, create, list, rewrite, convert and info for scripts, same planner/backends/settings, offline by default (`--online`), `--report`, exit codes; self-contained trimmed single file.
- Queue search (Ctrl+F), status filter and sorting; filter for image contents.
- Dark, light or Windows theme and six accent colors; check marks, selections, sliders and progress bars follow the accent.
- Emulator integration: Xemu/Xenia executables and game libraries, RetroBat and Batocera targets (`roms\xbox`, `roms\xbox360`); single-file results are placed directly in library folders; Start in emulator.
- Local crash logs (newest ten) with a notice on the next start and Open log folder in Settings.
- Polish and Danish UI (flat flags, Nordic cross for Danish).

### Changed and fixed

- Inline job details no longer squeeze the window: the drawer is a real layout row, the workspace always gets the full viewport width, the queue keeps a minimum height, and on small displays the arrow opens the details card instead.
- Taskbar icon: new ICO with 15 sizes (16–256, incl. 20/30/36/40/60/72/80/96 for 125–200 % scaling), small sizes as uncompressed bitmaps; shared AppUserModelID for the process and the installer shortcuts.
- Console selection now comes before the operation.
- "Xbox Classic" naming throughout (console, profiles, queue, README); new short description: "X-Shard is an Xbox 360 and Xbox Classic ISO tool for the community".
- "local-first" wording removed from README and descriptions (behavior unchanged: offline by default, Yes/No before external services).
- Projects: `XShard.Core` (shared, net10.0), `XShard` GUI (net10.0-windows10.0.19041.0, runs on Windows 10 1809+), `XShard.Cli`; JSON persistence uses source-generated metadata.
- Repository: `LICENSE.md` in the root with an identical copy `licenses/X-Shard-LICENSE.md`; legal reader documents back in `docs/legal` (byte-identical to 0.1.6, no new acceptance needed when updating from 0.1.6); `docs/FEATURES.md`.
- Release script publishes both EXEs into one folder; installer sets the AppUserModelID and offers the context-menu task.

## 0.1.7

- Consent: X-Shard contacts no external service on its own. Opening a website/repository link (About and links inside the legal reader) and disabling XGDTool offline mode each require an explicit Yes/No confirmation card. No, Escape and a background click decline.
- Online consent is per session: every start of X-Shard begins in offline mode. Queued jobs saved with offline mode disabled ask again on Start; No runs them offline. Source-content inspection always lists offline.
- Auto UI scaling now adapts to the logical window size (Windows DPI already applied): 100% from 1280×820, reduced in 5% steps down to 70% so compact 11–14" displays show all cards without vertical scrolling.
- Settings in two columns (one column on narrow windows) with grouped cards; flat 2D vector flags beside each language name (English, German, Spanish, French built in; optional `Flag` attribute for additional XML languages).
- Vertically centered text in the UI-scaling percentage pill and the settings/queue location pill (pill text is centered globally).
- New gear icon for the Settings button; new Job details icon for the footer button and the Job details title.
- Footer button reads only "Job details".
- About shows the author "Sven Klocke" above sksdesign | complicatiion.
- Device profiles read "Xbox · Xemu Emulator" and "Xbox 360 · Xenia Emulator".
- Skip $SystemUpdate is on by default for Xbox extraction, including a one-time default migration for settings written by earlier versions.

### Build and project structure

- A Visual Studio **Release** build now runs the release script automatically (MSBuild target `XShardPackageRelease`): self-contained single-file publish, portable ZIP, Inno Setup installer and SHA-256 files. Opt-out via `XShardPackageOnBuild=false`, portable only via `XShardBuildInstaller=false`; recursion guard `XShardReleaseScript`.
- Release script: strict mode, MSBuild-formatted errors (`XSB001`), early Inno Setup 6.3+ detection (PATH, registry, Program Files, per-user), cleanup of VS MSBuild environment variables, separate publish intermediate/output folders, temporary source stage removed, old GUI source archives pruned, optional `-RunVerification`, extended output checks.
- Installer: `{autopf}` install folder, AppVerName/VersionInfo/UninstallDisplayName, compile-time check for Inno Setup 6.3+.
- Repository layout: `LICENSE` in the root with an identical copy `licenses/X-Shard-LICENSE.txt` (kept in sync by the script); third-party licenses moved to `licenses/`; source accompaniment moved to `sources/`; `docs/` contains only CHANGELOG.md, DEPENDENCIES.md and FEATURES.txt; all further documents in `docs/nfo/` (legal reader documents in `docs/nfo/legal`).
- EULA path reference updated to `docs/nfo/legal`; the legal reader asks for acceptance once more after updating.

## 0.1.6

- Reserve a dedicated Settings scroll gutter; auto-hide the legal reader scrollbar and remove its redundant subtitle.
- Persistent output-options card for Xbox 360 and advanced workflows; responsive adjacent Rename XBE/Offline options.
- Red/green output chooser and matching neutral output-required note.
- Highlight the selected language button; localize the scaling note prefix.
- Relocate settings, queue and consent together with collision protection and a stable startup pointer.
- Center opaque notifications and automatically dismiss after five seconds.
- Publish backends in dedicated subfolders; use the color icon for the window and Windows shortcuts.
- Program Files x64 installer with seven sequential formatted legal pages and mandatory acknowledgment.
- End-user README adapted from the supplied template; standalone project GPLv3 Markdown.

## 0.1.5

- Maximized startup; remove automatic enlargement on maximize.
- Auto/Small/Medium/Large/Custom zoom and a 100–200% slider; persist/reset preferences.
- English, German, Spanish and French UI via extensible local XML and live captions.
- Compact legal/about cards; centered GPL Markdown with a separate scroll gutter.
- GPL-3.0-only project license, synchronized legal notices and GUI source accompaniment.
- Clear All; rounded queue rows and aligned equal-width status/action columns.
- Stable-width themed XGD expander, centered source/output buttons and narrower centered backend test.
- Timed analysis/preparation feedback without fabricated progress.
- Single-row detail actions, conditional title pill, directional drawer arrow and optional outer scrolling.
- Backdrop dismissal for ordinary modals; initial legal dialog remains mandatory.

## 0.1.4

- Aligned source/output buttons; output-required pill beside job options; larger logo without backdrop.
- Queue source, operation, console, outcome, status and duration pills; fixed status widths; per-job output shortcut.
- Viewport-sized, DPI-aware glass overlays and an independently toggled inline details drawer.
- Lazy source-content inspection for all jobs, directory indexing without traversing symbolic links, explicit loading/error states and refresh.
- XGD formats XISO, GoD, CCI, CSO, ZAR and Extract; console-specific Xemu/Xenia/console presets; scrub None/Partial/Full; split and XBE options with capability checks.
- Expanded profiles preserve offline mode rather than invoking upstream auto-profile flags that discard settings.
- Job-count total progress and live per-stage XGD progress; live elapsed time.
- Backend test button states, full-width detection pills, settings-path pill and confirmed app reset including legal consent.
- Research notes and expanded verification harnesses.

## 0.1.3

- Xbox 360 backend routing and per-job system snapshots.
- Publisher Markdown documents and full GPLv3 reader integrated; source accompaniment included.

## 0.1.2

- Green theme, glass modals, batch folder input, bundled XGDTool and legal onboarding.

## 0.1.1

- Initial Visual Studio project, native MVVM, asynchronous queue, portable and installer scripts.
