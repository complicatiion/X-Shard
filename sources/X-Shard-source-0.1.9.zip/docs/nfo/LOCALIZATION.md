# UI localization and scaling — v0.1.9

English is the default. Settings discovers language buttons from `Localization/*.xml` beside the application. German, Spanish, French, Polish and Danish are supplied. Selection applies immediately and is saved with settings. Backend logs and authoritative legal texts are not machine-translated.

To add a language, copy `Localization/en.xml` to e.g. `it.xml`, set the root attributes `Code="it"` and `Name="Italiano"` (optionally `Flag`, see below), and translate String values without changing Key attributes. Restart X-Shard to discover the new button. No recompilation is required. XML entities must be escaped normally; DTDs/external entities are prohibited. Keep filenames to letters, digits and hyphens. Missing entries fall back to English; unknown or invalid files do not block startup. English is embedded as a baseline and external files can override it.

```xml
<?xml version="1.0" encoding="utf-8"?>
<Language Code="it" Name="Italiano" Flag="v:#009246,#FFFFFF,#CE2B37">
  <String Key="settings">Impostazioni</String>
  <String Key="state_waiting">In attesa</String>
</Language>
```

Auto follows Windows monitor DPI and fits the logical window size: 100% from 1280×820 logical units, otherwise reduced in 5% steps down to 70% so compact 11–14" displays show all cards without vertical scrolling. Auto never zooms above 100%. Small = 90%, Medium = 100%, Large = 125%. Choose Custom to enable the 100–200% slider. High manual zoom on a small display enables workspace scrolling rather than hiding controls. Reset restores Auto, English and the default detail-scroll setting.

Each language button shows a flat 2D flag left of its name. Flags are drawn as vector shapes — no emoji, image files or downloads. English, German, Spanish, French, Polish and Danish (plus Italian, Dutch, Russian, Austrian, Belgian and Irish stripe flags and Swedish, Finnish, Norwegian and Icelandic Nordic crosses) are built in. Other languages can define stripes with the optional root attribute `Flag`: `h:` for horizontal or `v:` for vertical stripes followed by up to eight comma-separated colors, e.g. `Flag="h:#000000,#DD0000,#FFCE00"`. Without a valid definition a neutral badge is shown.

The active language button is highlighted green. No separate language-name status is displayed. The scaling hint prefix is localized along with its text.
