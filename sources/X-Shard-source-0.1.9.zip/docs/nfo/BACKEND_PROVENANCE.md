# Backend provenance

- Upstream: https://github.com/XboxDev/extract-xiso
- Source reference: `3f5b62cfe68f000b0e3c8a30104973f3a297948e` (master snapshot retrieved 2026-10-17).
- Frozen source: `sources` (repository root).
- Backend version: upstream 2.7.1.
- Windows x64 binary rebuilt from the supplied C sources using MinGW GCC 13-posix.
- Build: `x86_64-w64-mingw32-gcc -O2 -static -o extract-xiso.exe extract-xiso.c`.
- Source was not modified.
- SHA-256: `90741664c3d46927d3b0a0b08ce77f16e69915938625cdebbc0cafa5ab6bb5e2`.
- PE imports: KERNEL32.dll and msvcrt.dll (Windows system components). No VCRUNTIME140 dependency.

The upstream release binary was inspected but replaced because it imported VCRUNTIME140.dll. The shipped backend uses static compiler runtime linkage and the Windows system C library.

This product includes software developed by in <in@fishtank.com>.
Original copyright and all conditions are preserved in `licenses/extract-xiso.txt` and beside the tool.

## XGDTool v1.0.0

Original developer: wiredopposite. Unmodified Windows x64 CLI from the upstream v1.0.0 release, renamed to XGDTool.exe.

SHA-256: `178576ffe9229209a127e76480ae28991648075354dafba9bd4dcd3a3afb8792`.

PE imports: KERNEL32, USER32, SHELL32, WS2_32, bcrypt, ADVAPI32, CRYPT32 (Windows system DLLs). No VCRUNTIME/MSVCP redistribution required by this binary's imports.

The accompanying source archive includes the original source tree, pinned ZArchive/cmake-bin2h/vcpkg submodules and original build/dependency recipes. See XGDTOOL.md. Original attribution and GNU GPL v3 are retained.
