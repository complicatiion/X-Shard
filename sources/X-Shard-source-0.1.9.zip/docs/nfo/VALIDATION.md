# Validation

Current test counts, coverage and platform limits are maintained in [VERIFICATION.md](VERIFICATION.md). Build and reproduction commands are in [BUILD_INSTRUCTIONS.md](BUILD_INSTRUCTIONS.md).

Synthetic extract-xiso round-trips use generated dummy data. XGDTool subprocess contract fixtures verify wrapper behavior; they do not demonstrate real Xbox 360 game conversion. Published backends reside in dedicated backends subfolders.

The seven legal reader document hashes are recorded in LEGAL_DOCUMENT_MANIFEST.json. The root canonical GNU GPL text and original third-party licenses remain unchanged. The GUI declaration and EULA were updated for the publisher's GPLv3 release choice.
