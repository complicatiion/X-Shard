# Community backend research — 2026-10-17

Primary repositories reviewed for v0.1.6. Repository claims below are not independent compatibility certification. No additional backend has been silently bundled.

| Project | Potential value for X-Shard | Decision |
|---|---|---|
| [XGDTool](https://github.com/wiredopposite/XGDTool) | Xbox/360 formats and device presets | Keep as conversion backend; latest listed release v1.0.0, exact source included. Map flags explicitly to preserve offline behavior. |
| [extract-xiso](https://github.com/XboxDev/extract-xiso) | Small established XISO backend | Keep for ordinary original Xbox operations. |
| [xdvdfs](https://github.com/antangelo/xdvdfs) | Original Xbox image metadata, deterministic content checksums, individual-file copy-out, path remapping | Best next narrowly scoped addition: inspect/verify and selective extraction. MIT; use dedicated adapter and fixture tests rather than compatibility-mode renaming. |
| [Repackinator](https://github.com/Team-Resurgent/Repackinator) | Original Xbox title metadata, artwork and attachers for compatible BIOS workflows | Useful design/reference project; much of format conversion already overlaps XGD. Any future reuse requires GPL/source accompaniment review and independently tested CLI contracts. |
| [xVerter](https://github.com/blank-query/xverter) | Repository advertises broader STFS/XBLA/DLC, CHD/archive handling and output verification | Candidate for a later isolated evaluation, not a replacement recommendation yet. Independently verify reproducible binaries, CLI, provenance and real title compatibility before integration. |

Recommended next work: optional deterministic source/output verification and selected-file extraction first; then title metadata preview and a documented compatibility matrix using lawful synthetic fixtures plus user-owned disc images. Treat STFS content packages separately from disc formats: a syntactically valid conversion does not establish game compatibility. Do not promise universal conversion or emulator/hardware compatibility based solely on matching a file extension.

Implementation-specific upstream source inspected: XGDTool main.cpp, InputHelper.cpp, InputHelper_FS.cpp, ImageWriter.cpp, XGDLog.cpp and TitleHelper. Automatic presets reset offline settings; standalone --xbe ignores the requested output directory. Both behaviors are explicitly handled/documented in X-Shard.
