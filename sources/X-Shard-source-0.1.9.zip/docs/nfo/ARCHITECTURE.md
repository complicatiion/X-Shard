# X-Shard 0.1.9 architecture

Windows 10/11 x64, .NET 10, Avalonia 11.3.22, compiled bindings. Native INotifyPropertyChanged/ICommand and System.Text.Json. Release publishes a self-contained single-file GUI; two independent backend EXEs, legal texts and backend source accompaniment travel alongside it. No .NET installation is required on the target PC. Linux/macOS are not released targets.

## v0.1.9 project structure

| Project | Target | Content |
| --- | --- | --- |
| `src/XShard.Core` | `net10.0` | Models, JobPlanner (destination naming, capability rules, profiles), backends (extract-xiso, XGDTool), queue, settings/legal storage, localization baseline, TitleInfoReader (XDVDFS, XBE, XPR/DXT icon decoder, XEX2, STFS), TargetPreview, RunReportService, CrashLog, EmulatorService. No UI references. |
| `src/XShard` | `net10.0-windows10.0.19041.0`, SupportedOSPlatformVersion 10.0.17763 | Avalonia GUI, view models, ThemeService, WindowsIntegration (AppUserModelID, toasts via WinRT, ITaskbarList3, FlashWindowEx, powrprof, registry context menu), SingleInstance (named pipe, current user only). |
| `src/XShard.Cli` | `net10.0` | `xshard-cli.exe`, trimmed single file (TrimMode partial). |

JSON persistence uses a source-generated `JsonSerializerContext` (settings, queue, legal acceptance, storage pointer); the reflection resolver is only combined in where the runtime enables it, so the trimmed CLI reads and writes the same files.

## v0.1.9 behavior notes

- **Layout:** `MainSurface` is sized to exactly viewport ÷ zoom (minimum 820 × 580 logical units, larger manual zoom scrolls). The `LayoutTransformControl` therefore never falls back to the child's minimum desired size, which caused the narrow, centered layout with the inline drawer. The drawer is a grid row; its height is `min(42 % of the surface, space left after header, job card, footer and a 170-unit queue minimum)`. Below 190 units the arrow opens the modal details instead.
- **Title info:** XDVDFS volume descriptors are probed at 0 (XISO), 0x18300000 (XGD1 redump), 0xFD90000 (XGD2) and 0x2080000 (XGD3). `default.xbe` is parsed from its certificate; the `$$XTIMAGE` (fallback `$$XSIMAGE`) XPR0 resource is decoded (DXT1/3/5, swizzled or linear ARGB) and encoded as PNG without external libraries. XEX2 execution info (0x00040006) gives Title ID, Media ID, version and disc; the security info (+0x178) the region. Names and icons of Xbox 360 titles come from STFS headers (title name 0x1691, title thumbnail 0x571A); encrypted XEX resources are not read and no console keys are used. Reads run on a background queue, one at a time.
- **Flatten:** library targets set `FlattenOutput`; when XGDTool produced exactly one file, it is moved into the output folder (collision-safe name) and `PublishedPath` records it. Otherwise the per-job container is published as before.
- **Reports:** built after every run from the jobs that left the Waiting state; sizes include later split parts; saved space = source − output of successful jobs.
- **Power actions:** never persisted; a cancellable 60-second countdown precedes `SetSuspendState` (hibernate) or `shutdown /s /t 0`.
- **Single instance:** a per-session mutex; later starts send their arguments over `XShard.Instance.v1` (PipeOptions.CurrentUserOnly) and exit. Arguments: `--extract|--convert|--create|--list <path>` or plain paths.
- **Toasts:** the AppUserModelID `sksdesign.XShard` is set for the process before the window exists and registered under `HKCU\Software\Classes\AppUserModelId` with name and icon, so portable copies work without a Start-menu shortcut. Installer shortcuts carry the same ID, so pinned and running icons share one taskbar button.
- **Theme:** all colors are `DynamicResource Xs*` brushes from theme dictionaries; ThemeService derives accent brushes per theme and updates the Fluent palette and `SystemAccentColor*` resources. Since 0.1.9: `Dark` = neutral gray with Mica (`TransparencyLevelHint` Mica→None, transparent window background only while Mica is active), `Xbox` = custom `ThemeVariant("Xbox", Dark)` with the green dictionary and a locked green accent, accent `Windows` = `PlatformSettings` AccentColor1 (live via `ColorValuesChanged`), `XsLogo` switches to the green logo in Light. Defaults: Dark + Green + English. Settings `DefaultsRevision` 3 resets 0.1.9 pre-release values (revision 2: `Xbox`/`Windows`) once to `Dark`/`Green`. Inline details drawer: height = space after the queue minimum (120) clamped to 220–420; if it does not fit, `MainSurface` grows and `WorkspaceScroll` scrolls — no modal fallback.

## Data flow

The window owns OS dialogs and navigation. MainViewModel captures every new job into an immutable XisoJobOptions record. BackendPolicy derives the engine from console, operation, advanced switch and profile: Xbox 360 and advanced operations use XGDTool; ordinary original Xbox Extract/Create/List/Rewrite use extract-xiso. Changing the current UI settings does not mutate queued jobs. JSON retains backwards-compatible enum values and optional record parameters.

JobQueueService runs one job at a time. JobExecutor validates source/destination and never overwrites existing destinations. Writing uses a unique private staging directory beside the destination and publishes by move only after backend success. Originals are retained; incomplete staging directories are retained and identified in the log. Cancellation kills the process tree and cancels stream readers. Arguments use ProcessStartInfo.ArgumentList, never a shell command. Both streams are drained asynchronously; XGD informational output on stderr is expected. Failure summaries are checked even if XGD returns exit zero.

## CLI mapping

| UI | extract-xiso | XGDTool |
|---|---|---|
| Extract | `[-s] -d stage -x source` | `--extract` |
| Create | `[-m] [-s] -c source stage.iso` | `--xiso` |
| List | `-l source` | `--list` |
| Rewrite | `[-m] [-s] -d stage -r working-copy` | `--xiso --full-scrub` |
| Convert | not used | one of `--xiso --god --cci --cso --zar --extract` |
| Scrub | backend default | no flag / `--partial-scrub` / `--full-scrub` |
| Split XISO | not exposed | `--split` |
| Generate attach XBE | not exposed | `--attach-xbe` on original Xbox image output |
| Allowed media / rename title | legacy `-m` disables default patching | `--am-patch` / `--rename` on original Xbox extraction |
| Offline | no network feature | `--offline` by default; omitted only on explicit opt-in |

Flags precede source and optional staging output directory. CCI/CSO are offered for original Xbox workflows; Xbox 360 offers XISO/GoD/ZAR/Extract. Backend discovery honors an explicit path, otherwise its dedicated backends/extract-xiso or backends/XGDTool directory, followed by legacy application root, tools and bin locations. Both backends ship in their dedicated subdirectories.

## Profiles and upstream limitations

Profiles apply editable settings and are snapshotted per job, rather than continually constraining user choices.

| Profile | Console | Format | Scrub | Other defaults |
|---|---|---|---|---|
| Original Xbox | Xbox | Extract | None | media patch and rename title |
| Xbox 360 | Xbox 360 | GoD | Full | XBE options off |
| Xemu | Xbox | XISO | Full | split/XBE options off |
| Xenia | Xbox 360 | XISO | Full | split/XBE options off |

Upstream v1.0.0 InputHelper replaces the entire OutputSettings structure when an automatic profile flag is used, discarding offline mode and explicit settings. X-Shard therefore expands profiles into explicit format/settings flags and never sends the automatic flags. Emulator profiles produce the same image/scrub settings, but use the backend's ordinary title subdirectory inside the job container instead of its auto-profile flat path. This naming difference has no effect on image data.

Upstream `--xbe` ignores its output directory and writes beside the input, potentially replacing default.xbe; X-Shard deliberately does not expose that unsafe standalone mode. The requested `--attach-xbe` alongside image output remains supported inside the staging container. XBE patch/rename affect extraction, not image conversion; UI capability checks prevent those no-op combinations. Split is limited to XISO. Scrub applies to image writers; extracted directories are newly authored and ZAR uses its own archive writer. `--debug`/`--quiet` are diagnostic presentation switches and are not job options.

## Contents and progress

DetailsPanel is instantiated separately for the modal and inline drawer with the same view model. The chevron alone toggles the inline drawer; the main footer button opens the modal. The drawer covers the lower queue area and does not shrink queue rows into an unusable strip. Source content is read separately from processing: directories are enumerated off the UI thread, without following reparse points; images and recognized GoD directories use the appropriate read-only list command. Selection changes cancel prior reads, reads time out after 60 seconds, display is capped at 100,000 entries, errors are visible and refresh is available. The view explicitly describes source contents, not a fabricated output index.

Total progress is the fraction of terminal jobs in the visible queue, including failed/cancelled jobs; this is completion of queue work, not a byte estimate or success percentage. Running XGD stage percentages come from its progress output and may restart between stages. Legacy operations without trustworthy overall percentages remain indeterminate. Elapsed times use the running timestamp and finalize from Stopwatch.

## UI and state

The main window starts maximized. Avalonia/Windows handle monitor DPI; Auto additionally fits the logical client size (see v0.1.7 below) and never zooms above 100%, so maximizing never enlarges controls. Settings offer Small (90%), Medium (100%), Large (125%) and Custom (100–200%). A shared layout transform applies the selected zoom immediately; scrollable workspaces preserve accessibility when a high manual zoom cannot fit. Modal dimensions are capped in logical units and bounded by the viewport, avoiding giant legal/about cards. The legal reader uses a separate document selector, a centered readable column, an overflow-only, auto-hiding scrollbar and a reserved gutter; GPL is reflowed Markdown rather than a fenced code block. The canonical plain GPL remains unmodified.

Settings/queue save atomically via temporary JSON replacement. Legal consent stores the SHA-256 digest of all seven local reader documents; document changes require acceptance again. Missing documents cannot be accepted. Reset requires an in-app confirmation, is disabled while processing, resets all preferences, clears queue history and removes acceptance. It never deletes sources or output files. Portable data lives beside portable.flag; installed data in LocalAppData/X-Shard. Backend tests use generation tracking so an old probe cannot overwrite reset state.

Default processing is fully offline. Turning off Offline mode explicitly permits upstream title/artwork lookups; some upstream endpoints are HTTP. The generated component notice documents this opt-in feature, while the publisher's original five legal documents remain byte-for-byte unchanged.


## v0.1.7 consent and compact scaling

X-Shard itself performs no network requests. The two paths that can reach external services are gated in MainViewModel.Consent: `OpenExternalLinkAsync` (About buttons and legal-reader hyperlinks via a custom Markdown.Avalonia HyperlinkCommand) accepts only absolute http/https URLs and opens the default browser after an explicit Yes; disabling `Offline` shows the same Yes/No card and only a Yes changes the value (the checkbox reverts otherwise). Consent is held in memory for the current session; settings always load with Offline on. Start re-checks waiting XGD jobs that were saved with Offline off and, on No, rewrites their options to Offline before running. Content inspection forces `--offline`. The confirmation card is the topmost overlay; No is focused by default, Escape and a backdrop click answer No, and a newer request answers an older pending one with No.

`MainViewModel.ComputeAutoScale` = min(width/1280, height/820) of the logical client size, floored to 5% steps and clamped to 70–100%. The window reports its client size on every resize; presets and Custom are unaffected. Settings switch between two and one column at 760 logical units of card width. AppSettings.DefaultsRevision (written as 1) applies new defaults once to older settings files: Skip $SystemUpdate becomes on; later explicit choices are kept.

Flags are drawn by FlagIcon as flat vector shapes (no emoji, bitmaps or downloads). Built-in flags exist for en (simplified Union Flag), de, es, fr and a few common stripe flags; XML languages may supply `Flag="h:#RRGGBB,…"` or `Flag="v:#RRGGBB,…"`. Unknown codes get a neutral badge.

## v0.1.6 presentation and localization

Queue rows use a rounded item template and a shared three-column action/status area: operation/console/result align above state/duration/output shortcut. Clear All removes queue metadata only and is unavailable during processing. The permanent output-options card is visible for Xbox 360 and advanced workflows, with no expander or backend-specific heading. Its checkbox WrapPanel places Rename XBE and Offline beside one another when space permits and wraps on narrow windows. The options card may scroll on small windows/manual zoom, while ordinary desktop layouts show expanded options completely.

DetailsPanel owns its single action header, including modal Close beside Refresh and Export. The empty title pill is hidden. The footer chevron switches direction. Inner log/content lists scroll independently, with an optional outer detail scrollbar for constrained heights. Backdrop clicks dismiss Settings/About/Details/Reset without responding to clicks inside cards. Initial legal acceptance cannot be dismissed this way.

LocalizationService loads secure local XML with DTDs prohibited, an embedded English baseline and optional file overrides. Four XML files ship beside the EXE in Localization. Language buttons are discovered from files; newly added valid XML files appear at startup. Runtime bindings observe a localization revision, allowing captions to update immediately. Enum/state labels and native picker captions are translated, while backend output and legal documents retain their original English text. Settings persist language, zoom and outer scrolling.

Quiet Xbox 360 preparation displays an elapsed-time analysis/preparation message in the total-progress header. Once actual XGD percentages arrive, the label changes to processing. This is activity feedback, not a fabricated analysis percentage or ETA.

X-Shard v0.1.6 uses GPL-3.0-only by the publisher’s choice. Root LICENSE, project declaration, EULA, About and notices agree; third-party licenses remain unchanged. The release script regenerates an exact GUI source accompaniment before publishing; the separate frozen XGD source archive is also included.

## v0.1.6 storage and installer

SettingsService keeps a stable bootstrap folder containing storage-location.json. A location change is serialized against writes, refuses collisions with owned files, copies settings.json/queue.json/legal-acceptance.json and atomically commits the pointer only after all copies succeed. The previous folder is retained as a backup. This is single-instance migration: close other app instances first. The chosen folder remains selected after Reset App; all preferences, queue and consent inside it reset. Installed binaries default to Program Files x64; per-user state defaults to LocalAppData until changed. Portable state defaults to data beside portable.flag.

Settings reserves 20 logical units beside content in addition to the scrollbar track. Language buttons share cached observable language options so active styling updates immediately. Notification expiry uses a cancellable five-second delay and dispatches dismissal to the UI thread; replacement messages restart the delay.

The installer renders the seven local Markdown reader documents into offline RTF with a small developer-only .NET tool. Inno Setup presents these after its canonical GPL page, in sequence with individual acknowledgment. Silent installation is disabled because this flow requires interaction. In-app first-start acceptance remains independent. Rendering precedes source capture and publish so the accompanying source archive contains the same legal pages. The installer's elevation installs binaries only; running the app needs no elevation.
