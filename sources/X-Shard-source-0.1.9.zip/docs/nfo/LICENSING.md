# License decision for v0.1.6

X-Shard v0.1.6 is released under GNU GPL version 3 only (SPDX: GPL-3.0-only), as requested by its publisher. Root LICENSE.md contains the unmodified canonical license; docs/legal/LICENSE_DECLARATION.md identifies the project and copyright. GPL-3.0.md is a reflowed presentation of that text for the in-app reader.

This is a project license choice, not a claim that starting an independent GPL executable automatically requires every GUI to use the same license. The GNU FAQ discusses independent programs and aggregation: https://www.gnu.org/licenses/gpl-faq.en.html#MereAggregation. Rights already granted for prior MIT releases are not retroactively revoked. Third-party framework MIT notices remain because those licenses still apply to those components.

The GUI and XGDTool corresponding sources, notices and build instructions accompany binary releases through the publish script. The independent extract-xiso backend retains its upstream license and attribution. The EULA/information pages do not impose additional restrictions on rights granted by GPLv3. Acceptance records acknowledgment of the presented documents; it is not evidence that every paragraph was read.
