# XGDTool integration — v0.1.9

Backend: [wiredopposite/XGDTool](https://github.com/wiredopposite/XGDTool), unmodified Windows x64 CLI v1.0.0. The executable, GPLv3 text, notices and corresponding source/build archive accompany the project and published output. Xbox 360 and advanced Xbox jobs use this adapter; ordinary Xbox jobs retain extract-xiso.

See [ARCHITECTURE.md](ARCHITECTURE.md) for the full CLI matrix, profile expansion and capability rules. Supported conversion formats are XISO, GoD, CCI, CSO, ZAR and Extract, subject to the selected console. Xemu/Xenia profiles select full-scrub XISO defaults. Original Xbox defaults to extracted files with XBE media/title patching; Xbox 360 defaults to full-scrub GoD. Profile settings remain editable and are frozen when a job is added.

Scrub None/Partial/Full, split XISO, attach XBE generation, allowed-media XBE patching, title rename and offline mode map to explicit CLI flags. Offline is on by default. Automatic backend preset flags are not passed because upstream replaces all options and loses --offline. The only preset difference is ordinary title-directory output nesting inside the per-job container. Standalone --xbe is not exposed because upstream writes next to the input instead of respecting the output directory. --attach-xbe alongside image output stays inside the private staging output.

Each write targets a fresh staging directory and publishes the complete directory, preserving GoD title IDs and split image parts. The original input is retained. Existing destinations are refused. Informational stderr is captured normally. Both process exit status and explicit failure summaries are checked; listing must emit the supported list marker. Incomplete output is retained at its logged staging path.

Source image contents are loaded through a separate --list request; source directories are indexed directly. Thus Create/Extract/Convert jobs have a useful contents view as well as List jobs. This view describes the source, not necessarily the output after scrub/patching.

Disabling Offline mode explicitly permits upstream title/artwork requests (Google, GitHub/Repackinator, XboxUnity), including HTTP endpoints. X-Shard does not perform online queries itself. Default offline operation needs no internet after installation. Since v0.1.7, disabling Offline mode requires an explicit Yes in a confirmation card, consent lasts only for the current session, every start begins offline, queued online jobs ask again on Start (No runs them offline) and source-content listing always passes --offline.

The automated subprocess fixture verifies the adapter contract, staging, failure interpretation and mixed queue routing. It does not replace real Windows tests with Xbox/360 game images, GoD output, emulator playback and console hardware. No universal compatibility claim is made.
