# Verification — v0.1.9

## v0.1.9 status

Version 0.1.9 was written without a .NET SDK, NuGet access or Windows in the authoring environment; nothing was compiled or executed there. Build and run both harnesses before publishing.

- UI harness additions: fresh install defaults to Dark + Green + English and requests Mica; Xbox theme applies the green dictionary and locks the accent picker; 0.1.8 settings keep theme/accent, 0.1.9 pre-release Xbox/Windows resets once to Dark/Green; job details arrow expands inline at 1080p and compact sizes without opening the modal; queue search box and dropdowns are 42 px; no dropdown shows leading icons; Open log/reports folder buttons share the card width equally; saving settings shows no "Settings saved" notification.
- Windows smoke test additions: Mica visible in Dark on Windows 11 (solid gray on Windows 10 / transparency off); changing the Windows accent color updates the "Windows" accent live; green logo in Light.

## v0.1.8 status

Like 0.1.7, version 0.1.8 was written without a .NET SDK, NuGet access or Windows in the authoring environment. Nothing was compiled or executed there. Build the solution and run both harnesses before publishing; fix compile errors first.

- Service harness (`installer/verification`, now referencing only `XShard.Core`, runs on Windows and Linux): adds job planner naming/duplicates/collisions/profile presets, synthetic XBE certificate + DXT1 title image (also inside a real XISO built by extract-xiso), synthetic XEX2 header, synthetic GoD/STFS header with icon, unknown image, target preview, flattened single-file XGD output, TXT/HTML reports, crash log, source-generated settings JSON, library folder resolution and Xemu launch arguments.
- UI harness (`installer/verification-ui`, now `net10.0-windows10.0.19041.0`, Windows only): adds console-before-operation order, inline drawer keeps the full workspace width and a visible queue (1080p and compact), modal fallback on small heights, queue search/filter, live light theme and accent, six languages and flags, four detail tabs.
- Windows smoke test additions: taskbar progress and toast at the end of a queue; hibernate/shutdown countdown with Cancel; installer context-menu task and Portable toggle; second start forwards files to the running window; `xshard-cli.exe help`, `info` and a small `extract`; Title tab with real Xbox Classic and Xbox 360 (GoD) titles; RetroBat/Batocera targets; Start in emulator; taskbar icon sharpness at 100/125/150 %.


## v0.1.7 status

The v0.1.7 changes were made without a .NET SDK or NuGet access in the authoring environment, so the harnesses were **extended but not executed** there. Run both harnesses (commands in BUILD_INSTRUCTIONS.md) and the Windows smoke test before publishing.

New/updated checks:

- Service harness: Auto-scale steps (1920×1040 → 100%, 1366×728 → 85%, 1280×640 → 75%, 1093×575 → 70%).
- UI harness: offline and Skip $SystemUpdate defaults; Auto stays 100% on 1080p and returns to 100% after shrinking; compact 1280×640 reduces zoom and shows expanded Xbox 360 options without vertical scrolling; 70% minimum; two-column settings; flag icons on language buttons; vertically centered scale and location pills; emulator profile labels; footer reads only "Job details"; Job details title icon; About author; offline-mode Yes/No consent (No keeps offline, Yes allows for the session); external-link consent with backdrop decline; non-web links ignored; new sessions start offline; legacy settings adopt Skip $SystemUpdate once while later explicit choices are kept; reset clears online consent.
- Windows smoke test additions: About/legal links show the confirmation card before any browser opens; unchecking Offline mode shows the card; a queue saved with Offline off asks on START; 11–14" laptop at 125–150% Windows scaling shows the main window without card scrollbars in Auto.

## v0.1.6 results

### Passed in the v0.1.6 environment

- 69 service/backend checks: real Linux extract-xiso synthetic image round-trips and byte identity; source/destination safety; cancellation; queue transitions; settings/legal persistence; XGD CLI mapping, failure handling and mixed backend selection through an isolated subprocess contract fixture.
- 56 headless UI checks: maximized default; compact capped legal card; full GPL vertical scrolling and code-fence removal; mandatory first-start overlay; normal scale when maximized; source inspection; rounded rows; permanent output card and expanded desktop fit; red/green output chooser; scrollbar gutter; active language marking; five-second notification expiry; settings/queue/consent relocation with restart and collision protection; four live languages preserving console/operation; custom scaling and persistence; 200% bounds; directional drawer; modal header actions; conditional title pill; background dismissal and card-padding protection; Clear All source retention; timed quiet-analysis feedback; reset defaults; embedded English, missing-key fallback, additional languages and blocked XML external entities.
- Seven offline installer RTF pages generated from the current Markdown documents. Inno script APIs reviewed against official Inno documentation.
- Screenshots inspected for compact/maximized queue, expanded XGD options, English/German settings, GPL start/scrolled, job details and centered reset dialog.
- Windows win-x64 self-contained Release publish built without additional application runtime requirements; bundled backend copies, legal/localization files and source accompaniment checked.

### Limits

This Linux environment did not execute the native Windows GUI, Inno Setup installer or PowerShell release script. Actual XGD conversions with Xbox/360 disc images, emulator playback and physical-console compatibility remain Windows acceptance checks. The subprocess fixture validates the wrapper contract, not disc-format correctness. Quiet analysis feedback is an activity/timer indication, not a real backend analysis percentage.

Reproduce checks using installer/verification and installer/verification-ui; BUILD_INSTRUCTIONS.md contains commands. Headless is a verification-only dependency.
