# Build and release — X-Shard 0.1.9

## Development requirements

- Windows 10/11 x64.
- Visual Studio with support for the .NET 10 SDK, or the .NET 10 SDK CLI.
- Optional Avalonia Visual Studio extension for XAML editing.
- .NET 10 SDK (includes the Windows targeting pack used for toast notifications).
- Inno Setup 6.3 or newer for installer compilation (required for the `x64compatible` architecture identifiers).
- PowerShell 7 is used automatically when installed; Windows PowerShell 5.1 also works.

These tools are needed by developers, not by end users. NuGet restore needs network access on the build machine. The application does not.

## Visual Studio

Avalonia build telemetry targets are excluded in the project; the release script also sets the documented telemetry opt-out variables.

Open `X-Shard.sln`, allow NuGet restore, select XShard as the startup project and run Debug. All assets and the Windows backend are included. Copying a normal Debug/Release build directory is not a release workflow.

### Release build in Visual Studio = complete release package

Switch the configuration to **Release** and build (Ctrl+Shift+B). After the normal build, the MSBuild target `XShardPackageRelease` (in `src/XShard/XShard.csproj`) runs `installer/publish-portable.ps1 -BuildInstaller`: self-contained single-file publish, portable ZIP, Inno Setup installer and SHA-256 files in `artifacts`. Progress appears in the Output window; errors appear in the Error List as `XSB001`. Debug builds are never affected.

| Property | Default | Effect |
| --- | --- | --- |
| `XShardPackageOnBuild` | `true` for Release inside Visual Studio, otherwise empty | Runs the release script after the build. Set to `true` for CLI builds: `dotnet build -c Release -p:XShardPackageOnBuild=true`. |
| `XShardBuildInstaller` | `true` | `false` creates only the portable ZIP (e.g. on machines without Inno Setup). |
| `XShardReleaseScript` | set by the script | Prevents the nested publish from starting the script again. |

Properties can be set per machine without editing the project, e.g. in a `Directory.Build.props` (not committed) or as environment variables. The nested publish uses the normal `obj`/`bin` folders after the Visual Studio build has finished.

## Publisher legal documents

The project GPLv3 declaration, updated EULA, privacy policy, legal notice and copyright notice are integrated under `docs/legal`. The first-start view additionally includes a component-license scope notice and the full GNU GPLv3 for X-Shard and XGDTool. All documents are copied automatically to build and publish output.

The first-start screen has Accept / Decline only. Accept stores a local content hash and timestamp; changes to any included legal document require acceptance again. Decline exits. No placeholder documents or temporary acceptance overrides are required. The release script verifies all required documents before packaging.

## Automated Portable and installer build

From the repository folder in PowerShell:

```powershell
.\installer\publish-portable.ps1
.\installer\publish-portable.ps1 -BuildInstaller
# Explicit Inno Setup location if it cannot be discovered:
.\installer\publish-portable.ps1 -BuildInstaller -IsccPath 'C:\Program Files (x86)\Inno Setup 6\ISCC.exe'
# Run both verification harnesses before publishing:
.\installer\publish-portable.ps1 -BuildInstaller -RunVerification
```

ISCC.exe is found via PATH, the Inno Setup registry entry, Program Files and the per-user install folder. The Inno Setup version is checked before the (long) publish step. Root `LICENSE.md` is authoritative; the script keeps `licenses/X-Shard-LICENSE.md` identical. The script also publishes `src/XShard.Cli` (trimmed single file) into the same folder and runs `xshard-cli version` as a smoke test.

Outputs under `artifacts`:

- `publish`: unmodified self-contained release output used by the installer.
- `portable`: same output plus `portable.flag`.
- `X-Shard_v0.1.9_win-x64_portable.zip`.
- `X-Shard_v0.1.9_win-x64_setup.exe` when requested.
- SHA-256 sidecars for finished archives/installers.

The script validates both CLI backends, the source archive and all seven legal reader files. The script reads the version from the csproj, verifies the bundled backend, invokes `dotnet publish -c Release -r win-x64 --self-contained true`, and checks its exit code. Release settings enable PublishSingleFile, IncludeNativeLibrariesForSelfExtract and EnableCompressionInSingleFile; trimming is disabled. .NET/Skia native libraries can be extracted to a runtime-managed temp directory on first launch. Application and backend have separate executable files.

## Backend reproduction

The executables are published as `backends/extract-xiso/extract-xiso.exe` and `backends/XGDTool/XGDTool.exe` and detected automatically. Manual overrides and legacy root/tools/bin lookup remain supported. XGDTool GPL/source accompaniment is verified by the release script. The original Xbox backend is built from XboxDev source with a statically linked MinGW runtime. It must not require a separately installed VCRUNTIME140.dll. A frozen source snapshot and license are in `docs/backend-source`; `installer/build-backend.ps1` supports rebuilding it on Windows with Visual Studio C++ tools and `/MT`. That developer-only compiler is not required to run X-Shard.

## Verification

```powershell
dotnet run --project installer/verification/XShard.Verification.csproj -- <path-to-extract-xiso.exe>
```

The verification harness uses generated dummy data, no game content. It checks parser/argument behavior, create/list/extract round-trip, collisions, rewrite source preservation, cancellation and queue states. It uses only .NET libraries. Its isolated XGDTool subprocess fixture checks command mapping, offline flags, stderr listing, zero-exit failures and safe publication without representing a real Xbox 360 disc test. It and can exercise the platform-equivalent backend on Linux for core logic checks.

Before distributing a public release, test the Portable package and Inno installer on clean Windows 10/11 x64 without .NET or Visual C++ redistributables installed. Check launch, drag/drop, all four modes, cancellation, settings, restart recovery, icon, install/update/uninstall and shortcuts. Linux cross-compilation cannot replace those OS tests.

## XGDTool

See XGDTOOL.md for backend mapping, exact upstream release and source/license accompaniment. Windows x64 release imports only Windows system DLLs. Its real Windows execution still requires the documented Windows smoke test.

## Verification

Run `dotnet run --project installer/verification/XShard.Verification.csproj -- <extract-xiso executable>` for synthetic image round-trips, path protection, cancellation, queue and CLI contract checks. The XGD contract fixture is not an actual Xbox 360 conversion.

UI verification lives in installer/verification-ui and uses Avalonia.Headless only for development. Run `dotnet run --project installer/verification-ui/XShard.UiCheck.csproj -p:RuntimeIdentifier=win-x64 -p:SelfContained=false -p:PublishSingleFile=false -- <absolute repository path>`. Windows installation and actual game conversions still require a real Windows acceptance run.

## GPL source accompaniment

The PowerShell release script regenerates `sources/X-Shard-source-0.1.9.zip` from the current GUI sources before publishing, excluding build output, backend binaries and nested GUI source archives. The GUI source archive and frozen XGD source archive are copied into `sources` beside the EXE. The supplied source project already includes its matching GUI archive. After modifying code, use the release script to regenerate it before distributing binaries. For a GUI-only rebuild, restore and publish src/XShard/XShard.csproj; to recreate the complete distribution, restore the backend executables to src/XShard/tools and copy the supplied XGD source archive into docs/backend-source. The backend licenses and build instructions are included separately.

Localization XML files must travel in the Localization directory beside X-Shard.exe. The embedded English baseline allows startup if external translations are missing.

## Installer legal pages and installation directory

The release script first runs installer/LegalDocuments.Build, a .NET-only developer tool that generates seven formatted RTF files from docs/legal. Inno Setup embeds these files and displays each as a separate page with required acknowledgment, in addition to the canonical GPL license page. All seven must be acknowledged before install; silent installation is rejected. Source Markdown remains available in the installed legal folder and the first-start app reader. After editing a legal document, regenerate the RTF files before invoking ISCC directly.

The installer requires admin privileges and defaults to `{autopf}\X-Shard` (64-bit Program Files). It does not reuse a previous per-user install directory. Start-menu/desktop shortcuts and the window use the color app-icon.ico. Portable distribution has no installer and uses the mandatory in-app reader. Installed per-user preferences are writable in LocalAppData by default and may be moved through Settings; application binaries stay in Program Files.

## Repository layout

| Path | Content |
| --- | --- |
| `README.md`, `LICENSE.md` | End-user README and the GNU GPLv3 project license. |
| `docs/` | `CHANGELOG.md`, `DEPENDENCIES.md`, `FEATURES.md` and the legal reader documents in `docs/legal`. |
| `docs/nfo/` | All further documents: architecture, build, localization, verification, backend notes. |
| `licenses/` | Copy of the project license (`X-Shard-LICENSE.md`) and all third-party licenses/notices; published to `licenses` beside the EXE. |
| `sources/` | GPL source accompaniment (GUI and XGDTool archives) and the frozen extract-xiso source; published to `sources` beside the EXE. |
| `Localization/`, `src/`, `installer/`, `preview/` | Language XML files, projects (`XShard.Core`, `XShard`, `XShard.Cli`), build/installer tooling, README preview images. |
